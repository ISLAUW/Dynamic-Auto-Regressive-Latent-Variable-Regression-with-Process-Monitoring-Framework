function [lx,ly,Px,Py,lamda_x,lamda_y,Tx2_lim,Ty2_lim,Qx_lim,Qy_lim]=PCA_train(X1,Y1)
% This function trains PCA-based monitoring
% X1,Y1 must be autoscaled

n=size(X1,1); 
lx=pc_number(X1);
ly=pc_number(Y1);
[Px,lamda_x,Tx2_lim,Qx_lim]=PCA(X1,lx);
[Py,lamda_y,Ty2_lim,Qy_lim]=PCA(Y1,ly);

