function [Y_predict,Yxg_predict,Yyg_predict] = drlvr_arx_predict(X1,Y1,X1_test,Y1_test,a,kappa_1,kappa_2,s1,s2)
% X1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% X1_test -- autoscaled input matrix of testing data
% Y1_test -- autoscaled output matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of dynamics
% kappa_1, kappa_2 -- the parameters of regularization term

[P,Q,C,W,Alpha,Beta] = drlvr_arx(X1,Y1,a,kappa_1,kappa_2,s1,s2);
R = W*pinv(P'*W);
[n,m] = size(X1_test); np = size(Y1_test,2);
s = max(s1,s2); N = n-s; 
Y_predict = zeros(n,np); 
Yxg_predict = zeros(n,np); Yyg_predict = zeros(n,np);

for l = 1:a
    T = X1_test*R;
    t = T(:,l);
    Ts = zeros(N,s2+1);
    for i = 0:s2
        Ts(:,i+1) = t(s2-i+1:s2-i+N,:);
    end
    
    q = Q(:,l);
    u = Y1_test*q;
    Us = zeros(N,s1);
    for i = 1:s1
        Us(:,i) = u(s-i+1:s-i+N,:);
    end
    
    alpha = Alpha(:,l);
    beta = Beta(:,l);
    
    us_t = Ts*beta;
    us_u = Us*alpha;
    us_hat = us_u + us_t;
    
    %Y_predict(1:s,:) = Y_predict(1:s,:) + t(1:s1)*C(:,l)';
    %Yxg_predict(1:s,:) = Yxg_predict(1:s,:) + t(1:s1)*C(:,l)';
    %Yyg_predict(1:s,:) = Yyg_predict(1:s,:) + t(1:s1)*C(:,l)';
    
    Y_predict(s+1:end,:) = Y_predict(s+1:end,:) + us_hat*C(:,l)';
    Yxg_predict(s+1:end,:) = Yxg_predict(s+1:end,:) + us_t*C(:,l)';
    Yyg_predict(s+1:end,:) = Yyg_predict(s+1:end,:) + us_u*C(:,l)';
end
