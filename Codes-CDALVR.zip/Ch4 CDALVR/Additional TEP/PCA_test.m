%% ———— PCA Testing————
function [Tx2_index,Ty2_index,Qx_index,Qy_index]=PCA_test(X1_test,Y1_test,Px,Py,lamda_x,lamda_y)
% This function tests PCA-based monitoring
% X1,Y1 must be autoscaled

n=size(X1_test,1);

for i=1:n
    x=X1_test(i,:)'; y=Y1_test(i,:)';
    tx=Px'*x; ty=Py'*y;
    Tx2_index(i)=tx'*pinv(lamda_x)*tx;
    Ty2_index(i)=ty'*pinv(lamda_y)*ty;
    xk=(eye(size(Px*Px'))-Px*Px')*x; Qx_index(i)=xk'*xk;
    yk=(eye(size(Py*Py'))-Py*Py')*y; Qy_index(i)=yk'*yk;
end
