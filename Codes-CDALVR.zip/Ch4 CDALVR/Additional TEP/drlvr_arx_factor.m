function [a,gamma_1,gamma_2,s1,s2] = drlvr_arx_factor(X1,Y1)
% choose the number of DrLVR_ARX factors by cross validation (a,gamma_1,gamma_2,s)
% a -- the number of latent variables
% gamma_1,gamma_2 -- the parameters of regularization term
% s1,s2 -- lags
% call functions: drlvr_arx, drlvr_arx_predict, drlvr_arx_mse

m = size(X1,2);
gamma_1 = 0.005; gamma_2 = 0.005;

for a = 1:5
    for s1 = 1:5
        for s2 = 1:5
            fun = @(XTRAIN,YTRAIN,XTEST,YTEST)(drlvr_arx_mse(XTRAIN,YTRAIN,XTEST,YTEST,a,gamma_1,gamma_2,s1,s2));
            vals = crossval(fun,X1,Y1);
            mse(a,s1,s2) = mean(vals);   
        end       
    end
end

sub = zeros(1,3);
for a = 1:5
    for s1 = 1:5
        for s2 = 1:5
            if mse(a,s1,s2) == min(min(min(mse)))
                sub = [a,s1,s2]; % 存放a的最大值的3个下标
            end
        end   
    end
end

a = sub(1,1);
s1 = sub(1,2);
s2 = sub(1,3);