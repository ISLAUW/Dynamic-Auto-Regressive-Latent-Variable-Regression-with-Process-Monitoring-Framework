function [MSE_overall,MSE_Yxg,MSE_Yyg] = drlvr_arx_mse(X1,Y1,X1_test,Y1_test,a,kappa_1,kappa_2,s1,s2)
% X1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% X1_test -- autoscaled input matrix of testing data
% Y1_test -- autoscaled output matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of dynamics
% kappa_1, kappa_2 -- the parameters of regularization term

s = max(s1,s2);
[Y_predict,Yxg_predict,Yyg_predict] = drlvr_arx_predict(X1,Y1,X1_test,Y1_test,a,kappa_1,kappa_2,s1,s2);

Y_error = Y1_test(s+1:end,:) - Y_predict(s+1:end,:); 
MSE_overall = sum(sum(Y_error.^2))/size(Y_predict(s+1:end,:),1); 

Yxg_error = Y1_test(s+1:end,:) - Yxg_predict(s+1:end,:); 
MSE_Yxg = sum(sum(Yxg_error.^2))/size(Yxg_predict(s+1:end,:),1);

Yyg_error = Y1_test(s+1:end,:) - Yyg_predict(s+1:end,:);
MSE_Yyg = sum(sum(Yyg_error.^2))/size(Yyg_predict(s+1:end,:),1);