% ———— Determine a,kappa,s by Cross-Validation (CV) ————
% a -- the number of latent variables
% gamma_1,gamma_2 -- the parameters of regularization term
% s1,s2 -- lags

clear all;
close all;
clc;

%% ———— Training Data: Normal Data ————
filename_1 = 'E:\Research\DALVR & DrLVR_ARX\TEP_FaultFree_Training.csv';
d00 = csvread(filename_1,1,4);

T = 5; n = size(d00,1)/T;

% ———— Data Sampling ————
X0 = zeros(n,33); Y0 = zeros(n,1); 
for i = 1:n
     X0(i,:) = [d00((T*i-1),1:22),d00((T*i-1),42:52)]; 
     Y0(i,:) = d00((T*i-1),38);
end

% ———— Autoscale the data ————
X1 = autos(X0); Y1 = autos(Y0);

tic
%% ———— Determine a,kappa by Cross-Validation (CV) ————
[a,gamma_1,gamma_2,s1,s2] = drlvr_arx_factor(X1,Y1);
toc

save drlvr_arx_factor_data a gamma_1 gamma_2 s1 s2