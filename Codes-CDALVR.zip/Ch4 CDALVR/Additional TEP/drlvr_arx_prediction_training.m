clear all
clc
close all
format short;
tic

%% ———— Data ————
% ———— Training Data: Normal Data ————
filename_1 = 'E:\Research\DALVR & DrLVR_ARX\TEP_FaultFree_Training.csv';
d00 = csvread(filename_1,1,4);

T = 5; n = size(d00,1)/T;

% ———— Data Sampling ————
X0 = zeros(n,33); Y0 = zeros(n,1); 
for i = 1:n
     X0(i,:) = [d00((T*i-1),1:22),d00((T*i-1),42:52)]; 
     Y0(i,:) = d00((T*i-1),38);
end

% ———— Testing Data ————
filename_2 =  'E:\Research\DALVR & DrLVR_ARX\TEP_FaultFree_Testing.csv';
d00_te = csvread(filename_2,1,4);

X0_te = d00_te;
n_te = size(X0_te,1)/T;
% ———— Data Sampling ————
X0_test = zeros(n_te,33); Y0_test = zeros(n_te,1); 
for j = 1:n_te
     X0_test(j,:) = [X0_te((T*j-1),1:22),X0_te((T*j-1),42:52)]; 
     Y0_test(j,:) = X0_te((T*j-1),38);
end

% ———— Autoscale the training data and testing data ————
[X1,mx_train,vx_train] = autos(X0);
[Y1,my_train,vy_train] = autos(Y0);

X1_test = autos_test(X0_test,mx_train,vx_train);
Y1_test = autos_test(Y0_test,my_train,vy_train);

%% ———— Parameter Determination————
load drlvr_arx_factor_data.mat
a=1;s1=1;s2=1; %0.3518
a=1;s1=1;s2=2; %0.3161
a=1;s1=1;s2=3; %0.3151
a=1;s1=1;s2=4; %0.3150
a=1;s1=1;s2=5; %0.3149
a=1;s1=1;s2=6; %0.3148
a=1;s1=1;s2=10; %0.3147

a=1;s1=2;s2=1; %0.4029
a=1;s1=2;s2=2; %0.3152
a=1;s1=2;s2=3; %0.3146 
a=1;s1=2;s2=4; %0.3146
a=1;s1=2;s2=5; %0.3145
a=1;s1=2;s2=10; %0.3144 !!!

a=1;s1=3;s2=1; %0.4231
a=1;s1=3;s2=2; %0.3866
a=1;s1=3;s2=3; %0.3146
a=1;s1=3;s2=4; %0.3146
a=1;s1=3;s2=5; %0.3145
a=1;s1=3;s2=6; %0.3144 !!!

a=1;s1=4;s2=1;




%a=2;s1=1;s2=1; %0.3793



s = max(s1,s2);

%% ———— MSE ————
%[P,Q,C,W,Alpha,Beta,Y1_debug] = drlvr_arx(X1,Y1,a,gamma_1,gamma_2,s1,s2);
%Y_error = Y1(s+1:end,:) - Y1_debug(s+1:end,:); 
%MSE_debug = sum(sum(Y_error.^2))/size(Y1_debug(s+1:end,:),1);

[Y1_predict,Y1xg_predict,Y1yg_predict] = drlvr_arx_predict(X1,Y1,X1,Y1,a,gamma_1,gamma_2,s1,s2);
[MSE_Y1,MSE_Y1xg,MSE_Y1yg] = drlvr_arx_mse(X1,Y1,X1,Y1,a,gamma_1,gamma_2,s1,s2);

% ———— Plotting ————
%n = size(Y1,1);
%figure
%subplot(3, 1, 1)
%plot(s+1:n, Y1_predict(s+1:n,1), 'r', s+1:n, Y1(s+1:n,1), 'b', 'LineWidth', 1.5);
%title("Y_{pred}")

%subplot(3, 1, 2)
%plot(s+1:n, Y1xg_predict(s+1:n,1), 'r', s+1:n, Y1(s+1:n,1), 'b', 'LineWidth', 1.5);
%title("Y_{xg}")

%subplot(3, 1, 3)
%plot(s+1:n, Y1yg_predict(s+1:n,1), 'r', s+1:n, Y1(s+1:n,1), 'b', 'LineWidth', 1.5);
%title("Y_{yg}")
%legend("Predicted values", "Actual values")

toc