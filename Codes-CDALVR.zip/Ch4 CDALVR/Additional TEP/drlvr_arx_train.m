function [R,Q,Alpha,P,W,C,Gama,Rc,Rx,Theta_x,Qc,Py,P_dx,P_sx,Lambda,Lambda_c,Lambda_dy,Lambda_y,Lambda_sx,Phi_dx,...,
   T2_lim,Tc2_lim,Tdy2_lim,Tsy2_lim,Tsx2_lim,Qy_lim,Qsx_lim,phi_dx_lim,Qdx_lim] = drlvr_arx_train(X1,Y1,a,gamma_1,gamma_2,s1,s2)

% this function trains DArLVR
% X1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% X1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of dynamics

[n,m] = size(X1); np = size(Y1,2);
g = max(s1,s2); N = n - g;

%% ———— DALVR ————
[P,Q,C,W,Gama,Alpha,~] = drlvr_arx(X1,Y1,a,gamma_1,gamma_2,s1,s2);

R = W*inv(P'*W);
T = X1*R;
Lambda = 1/n * T'*T;

% T_ortho_test = T(:,1)'*T(:,2)
% P_ortho_test = norm((eye(size(P*R')) - P*R')^2) - norm(eye(size(P*R')) - P*R');

%% ———— Decomposition ———— 
% ———— For predictable quality variations ————
% Predictable output
Yh_xg = zeros(n-g,np); 
for i = 1:a
    for j = 0:s2
        Yh_xg = Yh_xg + Alpha(j+1,i)*X1(g+1-j:n-j,:)*R*C';
    end     
end
% Yh_xg = (Zx*kron(alpha,R))*C'; % process-quality / predictable output

% Auto-regressive quality part
Yh_yg = zeros(n-g,np);
for i = 1:a
    for j = 1:s1
        Yh_yg = Yh_yg + Gama(j,i)*Y1(g+1-j:n-j,:)*Q*C';
    end     
end
% Yh_yg = (Zy*kron(gama,C))*C'; % auto-regressive quality part

% Perform SVD for Yh_xg (predictable output)
[Uc Dc Vc] = svd(Yh_xg,'econ');
if size(Dc,2) == 1
    Sc = Dc(1); 
else
    Sc = diag(Dc); 
    Sc = Sc(diag(Dc)>0.001);
end
lc = length(Sc);

Vc = Vc(:,1:lc);
Dc = Dc(1:lc,1:lc);

Qc = Vc*Dc;
%Qc = Vc;
Rc = R*C'*Vc*inv(Dc);
Uc = Yh_xg*Vc*inv(Dc);

% X_Alpha = Uc*pinv(Rc);
X_Alpha = zeros(n-s2,m); 
for i = 1:a
    for j = 0:s2
        X_Alpha = X_Alpha + Alpha(j+1,i)*X1(s2+1-j:n-j,:);
    end     
end
Lambda_c = 1/(N-1)*Uc'*Uc;

% for Yh_yg
Uh_Gama = zeros(n-g,np); 
for i = 1:a
    for j = 1:s1
        Uh_Gama = Uh_Gama + Gama(j,i)*Y1(g+1-j:n-j,:);
    end     
end
l_dy = pc_number(Yh_yg);
Lambda_dy = 1/(N-1) * Uh_Gama'*Uh_Gama;

% Perform PCA for unpredictable output Yc
Yc = Y1(g+1:end,:) - Yh_xg - Yh_yg;
[Uy Dy Vy] = svd(Yc,'econ');
if size(Dy,2) == 1
    Sy = Dy(1);
else
    Sy = diag(Dy); 
    % Sy = Sy(diag(Dy)>0.001);
end
l_sy = pc_number(Yc);
Py = Vy(:,1:l_sy);
Ty = Yc*Py;
% Lambda_y = 1/(N-1) * diag(Sy(1:ly).^2);
Lambda_y = 1/(N-1) * Ty'*Ty;

% Py_ortho_test = norm((eye(size(Py*Py')) - Py*Py')^2) - norm(eye(size(Py*Py')) - Py*Py')

% Perform DiPCA for X
[P_dx, Rx, Theta_x, Th_dx, P_tx, Lambda_dx, Tdx2_lim] = DiPCA(X1,a,s2);
% [P_dx, Rx, Theta_x, Th_dx, P_tx, Lambda_dx, Tdx2_lim, Qdx_lim] = DiPCA(X1,a,s);
Xs1 = X1(s2+1:n,:);
Er = Xs1 - Th_dx*P_dx';

%l_sx0 = pc_number(Er'*Er);
%[U_er,D_er,V_er] = svd(Er,'econ');
%P_sx = V_er(:,1:l_sx0);
%T_sx = Er * P_sx; 
%if size(D_er,2) == 1
    %S_er = D_er(1);
%else
    %S_er = diag(D_er);
%end
%l_sx = length(S_er);
%Lambda_sx = 1/(N-1) * diag(S_er(1:l_sx0).^2);

l_sx = pc_number(Er'*Er);
[P_sx, Lambda_sx, Tsx2_lim, Qsx_lim] = PCA(Er,l_sx);

% Pdx_ortho_test = norm((eye(size(P_dx*P_dx')) - P_dx*P_dx')^2) - norm(eye(size(P_dx*P_dx')) - P_dx*P_dx');
% Psx_ortho_test = norm((eye(size(P_sx*P_sx')) - P_sx*P_sx')^2) - norm(eye(size(P_sx*P_sx')) - P_sx*P_sx');

%% ———— DALVR control limit for detection ————
alpha = 0.01; level = 1-alpha; 

% ———— T2_lim ————
T2_lim = (a*((N+1)^2-1)/((N+1)*(N+1-a)))*finv(level,a,N-a); 
Tc2_lim = chi2inv(level,lc); 
Tdy2_lim = chi2inv(level,l_dy); 
Tsy2_lim = chi2inv(level,l_sy); 
%Tsx2_lim = chi2inv(level,l_sx);

% ———— Q_lim ————
% Static Quality Resudial Subspace (SQRS)
for i = g+1:n
    x = X1(i,:)'; 
    y = Y1(i,:)';
    x_Alpha = X_Alpha(i-g,:)';  
    uh_Gama = Uh_Gama(i-g,:)';
    %uc=Rc'*x_Alpha;
    uc = Uc(i-g,:)';
    %yct = y - Qc*uc - C*uh_Gama;
    yct = y - Yh_xg(i-g,:)'- Yh_yg(i-g,:)';
    Qy_index(i) = yct'*(eye(size(Py*Py'))-Py*Py')*yct;
end

% Static Prth_dxincipal Residual Subspace (SPRS)
for i = g+1:n
    th_dx = Th_dx(i-g,:)';    
    ex = x - P_dx*th_dx;
    e_sx = (eye(size(P_sx*P_sx')) - P_sx*P_sx')*ex;
    Qsx_index(i) = e_sx'*e_sx;
    Qdx_index(i) = ex'*ex;
end

a_sy = mean(Qy_index); b_sy = var(Qy_index); 
g_sy = b_sy/(2*a_sy); h_sy = 2*a_sy^2/b_sy;
Qy_lim = g_sy * chi2inv(level,h_sy);

%a_sx = mean(Qsx_index); b_sx = var(Qsx_index); 
%g_sx = b_sx/(2*a_sx); h_sx = 2*a_sx^2/b_sx;
%Qsx_lim = g_sx * chi2inv(level,h_sx);

a_dx = mean(Qdx_index); b_dx=var(Qdx_index); 
g_dx = b_dx/(2*a_dx); h_dx=2*a_dx^2/b_dx;
Qdx_lim = g_dx * chi2inv(level,h_dx);

% ———— Dynamic Process Principal Subspace (DPPS) ————
S_dx = 1/(size(Th_dx,1)-1) * (Th_dx'*Th_dx); % sample covariance
% Phi_dx = P_tx*inv(Lambda_dx)*P_tx'/chi2inv(level,l_dx)+(eye(size(P_tx*P_tx'))-P_tx*P_tx')/(g_dx*chi2inv(level,h_dx));
Phi_dx = P_tx*inv(Lambda_dx)*P_tx'/Tdx2_lim+(eye(size(P_tx*P_tx'))-P_tx*P_tx')/Qdx_lim;

g_dx_phi = trace((S_dx*Phi_dx)^2)/trace(S_dx*Phi_dx);
h_dx_phi = (trace(S_dx*Phi_dx))^2/trace((S_dx*Phi_dx)^2);
phi_dx_lim = g_dx_phi * chi2inv(level,h_dx_phi);
