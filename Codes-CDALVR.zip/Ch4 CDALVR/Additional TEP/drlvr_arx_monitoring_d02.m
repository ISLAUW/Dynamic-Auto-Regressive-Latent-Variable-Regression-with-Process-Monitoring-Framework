clear all
clc
close all
format short;
tic

%% ———— Data ————
% ———— Training Data: Normal Data ————
filename_1 = 'E:\Research\DALVR & DrLVR_ARX\TEP_FaultFree_Training.csv';
d00 = csvread(filename_1,1,4);

T = 5; n = size(d00,1)/T;

% ———— Data Sampling ————
X0 = zeros(n,33); Y0 = zeros(n,1); 
for i = 1:n
     X0(i,:) = [d00((T*i-1),1:22),d00((T*i-1),42:52)]; 
     Y0(i,:) = d00((T*i-1),38);
end

% ———— Testing Data ————
filename_2 = 'E:\Research\DALVR & DrLVR_ARX\TEP_Faulty_Training.csv';
% fault number = 20
d00_te0 = csvread(filename_2,1,4);

round = 100; 
faulty_number = 2;
n_te0 = round * 500;
m_te0 = size(d00_te0,2);
d00_te = zeros(n_te0,m_te0);
for i = 1:round
    d00_te((i-1)*500+1:i*500,:) = d00_te0((i-1)*500*20+(faulty_number-1)*500+1:(i-1)*500*20+(faulty_number-1)*500+500,:);
end

X0_te = d00_te;
n_te = size(X0_te,1)/T;
% ———— Data Sampling ————
X0_test = zeros(n_te,33); Y0_test = zeros(n_te,1); 
for j = 1:n_te
     X0_test(j,:) = [X0_te((T*j-1),1:22),X0_te((T*j-1),42:52)]; 
     Y0_test(j,:) = X0_te((T*j-1),38);
end

% ———— Autoscale the training data and testing data ————
[X1,mx_train,vx_train] = autos(X0);
[Y1,my_train,vy_train] = autos(Y0);

X1_test = autos_test(X0_test,mx_train,vx_train);
Y1_test = autos_test(Y0_test,my_train,vy_train);

%% ———— Parameter Determination————
load drlvr_arx_factor_data.mat
% a = 1; s1 = 1; s2 = 1;
s = max(s1,s2);

%% ———— MSE ————
%[P,Q,C,W,Alpha,Beta,Y1_debug] = drlvr_arx(X1,Y1,a,gamma_1,gamma_2,s1,s2);
%Y_error = Y1(s+1:end,:) - Y1_debug(s+1:end,:); 
%MSE_debug = sum(sum(Y_error.^2))/size(Y1_debug(s+1:end,:),1);

[Y1_predict,Y1xg_predict,Y1yg_predict] = drlvr_arx_predict(X1,Y1,X1,Y1,a,gamma_1,gamma_2,s1,s2);
[MSE_Y1,MSE_Y1xg,MSE_Y1yg] = drlvr_arx_mse(X1,Y1,X1,Y1,a,gamma_1,gamma_2,s1,s2);

% ———— Plotting ————
n = size(Y1,1);
figure
subplot(3, 1, 1)
plot(s+1:n, Y1_predict(s+1:n,1), 'r', s+1:n, Y1(s+1:n,1), 'b', 'LineWidth', 1.5);
title("Y_{pred}")

subplot(3, 1, 2)
plot(s+1:n, Y1xg_predict(s+1:n,1), 'r', s+1:n, Y1(s+1:n,1), 'b', 'LineWidth', 1.5);
title("Y_{xg}")

subplot(3, 1, 3)
plot(s+1:n, Y1yg_predict(s+1:n,1), 'r', s+1:n, Y1(s+1:n,1), 'b', 'LineWidth', 1.5);
title("Y_{yg}")
legend("Predicted values", "Actual values")

toc

[Y_predict,Yxg_predict,Yyg_predict] = drlvr_arx_predict(X1,Y1,X1_test,Y1_test,a,gamma_1,gamma_2,s1,s2);
[MSE_overall,MSE_Yxg,MSE_Yyg] = drlvr_arx_mse(X1,Y1,X1_test,Y1_test,a,gamma_1,gamma_2,s1,s2);

% ———— R2 ————
% R2_Yh = corrcoef(Y1_test(s+1:end,:),Y_predict(s+1:end,:));
% R2_Yhyg = corrcoef(Yyg_predict(s+1:end,:),Y1_test(s+1:end,:));
% R2_Yhxg = corrcoef(Yxg_predict(s+1:end,:),Y1_test(s+1:end,:));

% ———— T ————
%R = W*pinv(P'*W); 
%T = X1*R;

% ———— Auto-correlation of T————
%auto_t1=autocorr(T(:,1));
%auto_t2=autocorr(T(:,2));

%figure;
%subplot(2,1,1);
%stem_t1=stem(auto_t1);
%subplot(2,1,2);
%stem_t2=stem(auto_t2);

% ———— Plotting ————
figure
subplot(3, 1, 1)
plot(s+1:n_te, Y_predict(s+1:n_te,1), 'r', s+1:n_te, Y1_test(s+1:n_te,1), 'b', 'LineWidth', 1.5);
title("Y_{pred}")

subplot(3, 1, 2)
plot(s+1:n_te, Yxg_predict(s+1:n_te,1), 'r', s+1:n_te, Y1_test(s+1:n_te,1), 'b', 'LineWidth', 1.5);
title("Y_{xg}")

subplot(3, 1, 3)
plot(s+1:n_te, Yyg_predict(s+1:n_te,1), 'r', s+1:n_te, Y1_test(s+1:n_te,1), 'b', 'LineWidth', 1.5);
title("Y_{yg}")
legend("Predicted values", "Actual values")

%% ———— Plotting ———— 
% ———— Training data ————
figure;
subplot(3,1,1);
plot(Y1_predict(1:100,:),'r', 'LineWidth', 1.5);
hold on
plot(Y1(1:100,:),'b');
legend('Predicting data','Actual Data')

subplot(3,1,2);
plot(Y1xg_predict(1:100,:),'r', 'LineWidth', 1.5);
hold on
plot(Y1(1:100,:),'b');

subplot(3,1,3);
plot(Y1yg_predict(1:100,:),'r', 'LineWidth', 1.5);
hold on
plot(Y1(1:100,:),'b');

% ———— Testing data ————
figure;
subplot(3,1,1);
plot(Y_predict(1:100,:),'r', 'LineWidth', 1.5);
hold on
plot(Y1_test(1:100,:),'b');
legend('Predicting data','Actual Data')
title('Y_{predict}')

subplot(3,1,2);
plot(Yxg_predict(1:100,:),'r', 'LineWidth', 1.5);
hold on
plot(Y1_test(1:100,:),'b');
title('Yxg_{predict}')

subplot(3,1,3);
plot(Yyg_predict(1:100,:),'r', 'LineWidth', 1.5);
hold on
plot(Y1_test(1:100,:),'b');
title('Yyg_{predict}')

toc

%% ———— DrLVR-ARX training ————
[R,Q,Alpha,P,W,C,Gama,Rc,Rx,Theta_x,Qc,Py,P_dx,P_sx,Lambda,Lambda_c,Lambda_dy,Lambda_y,Lambda_sx,Phi_dx,...,
    T2_lim,Tc2_lim,Tdy2_lim,Ty2_lim,Tsx2_lim,Qy_lim,Qsx_lim,phi_dx_lim] = drlvr_arx_train(X1,Y1,a,gamma_1,gamma_2,s1,s2);

%% ———— DrLVR-ARX testing ————
% ———— Obtain the indices for the testing data ————
[T2_index_test,Tc2_index_test,Tdy2_index_test,Ty2_index_test,Qy_index_test,phi_dx_index_test,Tsx2_index_test,Qsx_index_test] = drlvr_arx_test(X1_test,Y1_test,...,
    a,gamma_1,gamma_2,s2,s1,R,Q,Alpha,P,W,C,Gama,Rc,Rx,Theta_x,Qc,Py,P_dx,P_sx,Lambda,Lambda_c,Lambda_dy,Lambda_y,Lambda_sx,Phi_dx);

% ———— Obtain the indices for the training data ————
[T2_index,Tc2_index,Tdy2_index,Ty2_index,Qy_index,phi_dx_index,Tsx2_index,Qsx_index] = drlvr_arx_test(X1,Y1,...,
    a,gamma_1,gamma_2,s2,s1,R,Q,Alpha,P,W,C,Gama,Rc,Rx,Theta_x,Qc,Py,P_dx,P_sx,Lambda,Lambda_c,Lambda_dy,Lambda_y,Lambda_sx,Phi_dx);

n = n + n_te;
% ———— T2 & Q ————
%figure;
%plot([1:n],[T2_index,T2_index_test],[1:n],T2_lim*ones(1,n),'r--');
%title('T^2');
%legend('statistic','control limit')

%figure;
%subplot(7,1,1);
%plot([1:n],[Tc2_index,Tc2_index_test],[1:n],Tc2_lim*ones(1,n),'r');
%title('T_c^2');
%legend('statistic','control limit')

%subplot(7,1,2);
%plot([1:n],[Tdy2_index,Tdy2_index_test],[1:n],Tdy2_lim*ones(1,n),'r');
%title('T_{dy}^2');

%subplot(7,1,3);
%plot([1:n],[Ty2_index,Ty2_index_test],[1:n],Ty2_lim*ones(1,n),'r--');
%title('T_y^2');

%subplot(7,1,4);
%plot([1:n],[Tsx2_index,Tsx2_index_test],[1:n],Tsx2_lim*ones(1,n),'r--');
%title('T_{sx}^2');

%subplot(7,1,5);
%plot([1:n],[Qy_index,Qy_index_test],[1:n],Qy_lim*ones(1,n),'r--');
%title('Q_y');

%subplot(7,1,6);
%plot([1:n],[Qsx_index,Qsx_index_test],[1:n],Qsx_lim*ones(1,n),'r--');
%title('Q_{sx}');

%subplot(7,1,7);
%plot([1:n],[phi_dx_index,phi_dx_index_test],[1:n],phi_dx_lim*ones(1,n),'r--');
%title('\phi_{dx}');

na = 100; % train
nb = 100; % test
n = na + nb;

Tc2_index = Tc2_index(1:na);
Tc2_index_test = Tc2_index_test(1:nb);
Tdy2_index = Tdy2_index(1:na);
Tdy2_index_test = Tdy2_index_test(1:nb);
Ty2_index = Ty2_index(1:na);
Ty2_index_test = Ty2_index_test(1:nb);
Tsx2_index = Tsx2_index(1:na);
Tsx2_index_test = Tsx2_index_test(1:nb);
Qsx_index = Qsx_index(1:na);
Qsx_index_test = Qsx_index_test(1:nb);
phi_dx_index = phi_dx_index(1:na);
phi_dx_index_test = phi_dx_index_test(1:nb);

% ———— size(Y,2)=1 ————
figure;
subplot(6,1,1);
plot([1:n],[Tc2_index,Tc2_index_test],[1:n],Tc2_lim*ones(1,n),'r--');
title('T_c^2');
legend('statistic','control limit');

subplot(6,1,2);
plot([1:n],[Tdy2_index,Tdy2_index_test],[1:n],Tdy2_lim*ones(1,n),'r--');
title('T_{dy}^2');

subplot(6,1,3);
plot([1:n],[Ty2_index,Ty2_index_test],[1:n],Ty2_lim*ones(1,n),'r--');
title('T_{sy}^2');

subplot(6,1,4);
plot([1:n],[Tsx2_index,Tsx2_index_test],[1:n],Tsx2_lim*ones(1,n),'r--');
title('T_{sx}^2');

subplot(6,1,5);
plot([1:n],[Qsx_index,Qsx_index_test],[1:n],Qsx_lim*ones(1,n),'r--');
title('Q_{sx}');

subplot(6,1,6);
plot([1:n],[phi_dx_index,phi_dx_index_test],[1:n],phi_dx_lim*ones(1,n),'r--');
title('\phi_{dx}');

%% —————— PCA-based monitoring on X & Y——————
% ———— PCA Training ————
[lx_pca,ly_pca,Px_pca,Py_pca,lambda_x_pca,lambda_y_pca,Tx2_lim_pca,Ty2_lim_pca,Qx_lim_pca,Qy_lim_pca]=PCA_train(X1,Y1);

% ———— PCA Testing ————
% —— Obtain the indices for the testing data ——
[Tx2_index_pca_test,Ty2_index_pca_test,Qx_index_pca_test,Qy_index_pca_test]=PCA_test(X1_test,Y1_test,Px_pca,Py_pca,lambda_x_pca,lambda_y_pca);

% —— Obtain the indices for the training data ——
[Tx2_index_pca,Ty2_index_pca,Qx_index_pca,Qy_index_pca]=PCA_test(X1,Y1,Px_pca,Py_pca,lambda_x_pca,lambda_y_pca);

Tx2_index_pca = Tx2_index_pca(1:na);
Ty2_index_pca = Ty2_index_pca(1:na);
Qx_index_pca = Qx_index_pca(1:na);
Qy_index_pca = Qy_index_pca(1:na);
Tx2_index_pca_test = Tx2_index_pca_test(1:nb);
Ty2_index_pca_test = Ty2_index_pca_test(1:nb);
Qx_index_pca_test = Qx_index_pca_test(1:nb);
Qy_index_pca_test = Qy_index_pca_test(1:nb);

% ———— PCA: T2 & Q ————
figure;
subplot(3,1,1);
plot([1:n],[Ty2_index_pca,Ty2_index_pca_test],[1:n],Ty2_lim_pca*ones(1,n),'r--');
title('T_y^2');
legend('statistic','control limit')

subplot(3,1,2);
plot([1:n],[Tx2_index_pca,Tx2_index_pca_test],[1:n],Tx2_lim_pca*ones(1,n),'r--');
title('T_x^2');

subplot(3,1,3);
plot([1:n],[Qx_index_pca,Qx_index_pca_test],[1:n],Qx_lim_pca*ones(1,n),'r--');
title('Q_x');

%subplot(2,2,4);
%plot([1:n],[Qy_index_pca,Qy_index_pca_test],[1:n],Qy_lim_pca*ones(1,n),'r--');
%title('Q_y');


%% ———— Fault Detection Rate (FDR) & Missing Alarm Rate (MAR) & Fault Alarm Rate (FAR) ————    
X1_test = X1_test(1:100,:);

% ———— T2 ————
TP_T2 = zeros(size(X1_test,1),1);
TN_T2 = zeros(size(X1_test,1),1);
FP_T2 = zeros(size(X1_test,1),1);
FN_T2 = zeros(size(X1_test,1),1);

for count=1:size(X1_test,1)
    if  (Tc2_index_test(count) > Tc2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca) || (Ty2_index_test(count) > Ty2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca)
        TP_T2(count) = 1;
    elseif (Tc2_index_test(count) < Tc2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca) && (Ty2_index_test(count) < Ty2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca)
        TN_T2(count) = 1;
    elseif (Tc2_index_test(count) > Tc2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca) || (Ty2_index_test(count) > Ty2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca)
        FP_T2(count) = 1;
    elseif (Tc2_index_test(count) < Tc2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca) && (Ty2_index_test(count) < Ty2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca)
        FN_T2(count) = 1;
    end
end

if sum(TP_T2) == 0 && sum(FN_T2) == 0
    FDR_T2 = 0
    MAR_T2 = 0;
else
    FDR_T2 = sum(TP_T2) / (sum(TP_T2) + sum(FN_T2))
    MAR_T2 = sum(FN_T2) / (sum(TP_T2) + sum(FN_T2));
end

if sum(FP_T2) == 0 && sum(TN_T2) == 0
    FAR_T2 = 0
else
    FAR_T2 = sum(FP_T2) / (sum(FP_T2) + sum(TN_T2))
end


% ———— Tc2 ————
TP_Tc2 = zeros(size(X1_test,1),1);
TN_Tc2 = zeros(size(X1_test,1),1);
FP_Tc2 = zeros(size(X1_test,1),1);
FN_Tc2 = zeros(size(X1_test,1),1);

for count = 1:size(X1_test,1)
    if Tc2_index_test(count) > Tc2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca
        TP_Tc2(count) = 1;
    elseif Tc2_index_test(count) < Tc2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca
        TN_Tc2(count) = 1;
    elseif Tc2_index_test(count) > Tc2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca
        FP_Tc2(count) = 1;
    elseif Tc2_index_test(count) < Tc2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca
        FN_Tc2(count) = 1;
    end
end

if sum(TP_Tc2) == 0 && sum(FN_Tc2) == 0
    FDR_Tc2 = 0
    MAR_Tc2 = 0;
else
    FDR_Tc2 = sum(TP_Tc2) / (sum(TP_Tc2) + sum(FN_Tc2))
    MAR_Tc2 = sum(FN_Tc2) / (sum(TP_Tc2) + sum(FN_Tc2));
end

if sum(FP_Tc2) == 0 && sum(TN_Tc2) == 0
    FAR_Tc2 = 0
else
    FAR_Tc2 = sum(FP_Tc2) / (sum(FP_Tc2) + sum(TN_Tc2))
end

% ———— Tdy2 ————
TP_Tdy2 = zeros(size(X1_test,1),1);
TN_Tdy2 = zeros(size(X1_test,1),1);
FP_Tdy2 = zeros(size(X1_test,1),1);
FN_Tdy2 = zeros(size(X1_test,1),1);

for count = 1:size(X1_test,1)  
    if Tdy2_index_test(count) > Tdy2_lim && Tx2_index_pca_test(count) > Ty2_lim_pca
        TP_Tdy2(count) = 1;
    elseif Tdy2_index_test(count) < Tdy2_lim && Tx2_index_pca_test(count) < Ty2_lim_pca
        TN_Tdy2(count) = 1;
    elseif Tdy2_index_test(count) > Tdy2_lim && Tx2_index_pca_test(count) < Ty2_lim_pca
        FP_Tdy2(count) = 1;
    elseif Tdy2_index_test(count) < Tdy2_lim && Tx2_index_pca_test(count) > Ty2_lim_pca
        FN_Tdy2(count) = 1;
    end
end

if sum(TP_Tdy2) == 0 && sum(FN_Tdy2) == 0
    FDR_Tdy2 = 0
    MAR_Tdy2 = 0;
else
    FDR_Tdy2 = sum(TP_Tdy2) / (sum(TP_Tdy2) + sum(FN_Tdy2))
    MAR_Tdy2 = sum(FN_Tdy2) / (sum(TP_Tdy2) + sum(FN_Tdy2));
end

if sum(FP_Tdy2) == 0 && sum(TN_Tdy2) == 0
    FAR_Tdy2 = 0
else
    FAR_Tdy2 = sum(FP_Tdy2) / (sum(FP_Tdy2) + sum(TN_Tdy2))
end

% ———— Tsy2 ————
TP_Tsy2 = zeros(size(X1_test,1),1);
TN_Tsy2 = zeros(size(X1_test,1),1);
FP_Tsy2 = zeros(size(X1_test,1),1);
FN_Tsy2 = zeros(size(X1_test,1),1);

for count = 1:size(X1_test,1)
    if Ty2_index_test(count) > Ty2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca
        TP_Tsy2(count) = 1;
    elseif Ty2_index_test(count) < Ty2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca
        TN_Tsy2(count) = 1;
    elseif Ty2_index_test(count) > Ty2_lim && Ty2_index_pca_test(count) < Ty2_lim_pca
        FP_Tsy2(count) = 1;
    elseif Ty2_index_test(count) < Ty2_lim && Ty2_index_pca_test(count) > Ty2_lim_pca
        FN_Tsy2(count) = 1;
    end
end

if sum(TP_Tsy2) == 0 && sum(FN_Tsy2) == 0
    FDR_Tsy2 = 0
    MAR_Tsy2 = 0;
else
    FDR_Tsy2 = sum(TP_Tsy2) / (sum(TP_Tsy2) + sum(FN_Tsy2))
    MAR_Tsy2 = sum(FN_Tsy2) / (sum(TP_Tsy2) + sum(FN_Tsy2));
end

if sum(FP_Tsy2) == 0 && sum(TN_Tsy2) == 0
    FAR_Ty2 = 0
else
    FAR_Ty2 = sum(FP_Tsy2) / (sum(FP_Tsy2) + sum(TN_Tsy2))
end

% ———— Tsx2 ————
TP_Tsx2 = zeros(size(X1_test,1),1);
TN_Tsx2 = zeros(size(X1_test,1),1);
FP_Tsx2 = zeros(size(X1_test,1),1);
FN_Tsx2 = zeros(size(X1_test,1),1);

for count = 1:size(X1_test,1)
    if Tsx2_index_test(count) > Tsx2_lim && Tx2_index_pca_test(count) > Tx2_lim_pca
        TP_Tsx2(count) = 1;
    elseif Tsx2_index_test(count) < Tsx2_lim && Tx2_index_pca_test(count) < Tx2_lim_pca
        TN_Tsx2(count) = 1;
    elseif Tsx2_index_test(count) > Tsx2_lim && Tx2_index_pca_test(count) < Tx2_lim_pca
        FP_Tsx2(count) = 1;
    elseif Tsx2_index_test(count) < Tsx2_lim && Tx2_index_pca_test(count) > Tx2_lim_pca
        FN_Tsx2(count) = 1;
    end
end

if sum(TP_Tsx2) == 0 && sum(FN_Tsx2) == 0
    FDR_Tsx2 = 0
    MAR_Tsx2 = 0;
else
    FDR_Tsx2 = sum(TP_Tsx2) / (sum(TP_Tsx2) + sum(FN_Tsx2))
    MAR_Tsx2 = sum(FN_Tsx2) / (sum(TP_Tsx2) + sum(FN_Tsx2));
end

if sum(FP_Tsx2) == 0 && sum(TN_Tsx2) == 0
    FAR_Tsx2 = 0
else
    FAR_Tsx2 = sum(FP_Tsx2) / (sum(FP_Tsx2) + sum(TN_Tsx2))
end

% ———— Qsy ————
TP_Qsy = zeros(size(X1_test,1),1);
TN_Qsy = zeros(size(X1_test,1),1);
FP_Qsy = zeros(size(X1_test,1),1);
FN_Qsy = zeros(size(X1_test,1),1);

for count = 1:size(X1_test,1)        
    if Qy_index_test(count) > Qy_lim && Qy_index_pca_test(count) > Qy_lim_pca
        TP_Qsy(count) = 1;
    elseif Qy_index_test(count) < Qy_lim && Qy_index_pca_test(count) < Qy_lim_pca
        TN_Qsy(count) = 1;
    elseif Qy_index_test(count) > Qy_lim && Qy_index_pca_test(count) < Qy_lim_pca
        FP_Qsy(count) = 1;
    elseif Qy_index_test(count) < Qy_lim && Qy_index_pca_test(count) > Qy_lim_pca
        FN_Qsy(count) = 1;
    end
end

if sum(TP_Qsy) == 0 && sum(FN_Qsy) == 0
    FDR_Qsy = 0
    MAR_Qsy = 0;
else
    FDR_Qsy = sum(TP_Qsy) / (sum(TP_Qsy) + sum(FN_Qsy))
    MAR_Qsy = sum(FN_Qsy) / (sum(TP_Qsy) + sum(FN_Qsy));
end
    
if sum(FP_Qsy) == 0 && sum(TN_Qsy) == 0
    FAR_Qsy = 0
else
    FAR_Qsy = sum(FP_Qsy) / (sum(FP_Qsy) + sum(TN_Qsy))
end


% ———— Qsx ————
TP_Qsx = zeros(size(X1_test,1),1);  
TN_Qsx = zeros(size(X1_test,1),1);
FP_Qsx = zeros(size(X1_test,1),1);
FN_Qsx = zeros(size(X1_test,1),1);

for count = 1:size(X1_test,1)    
    if Qsx_index_test(count) > Qsx_lim && Qx_index_pca_test(count) > Qx_lim_pca
        TP_Qsx(count) = 1;
    elseif Qsx_index_test(count) < Qsx_lim && Qx_index_pca_test(count) < Qx_lim_pca
        TN_Qsx(count) = 1;
    elseif Qsx_index_test(count) > Qsx_lim && Qx_index_pca_test(count) < Qx_lim_pca
        FP_Qsx(count) = 1;
    elseif Qsx_index_test(count) < Qsx_lim && Qx_index_pca_test(count) > Qx_lim_pca
        FN_Qsx(count) = 1;
    end
end
if sum(TP_Qsx) == 0 && sum(FN_Qsx) == 0
    FDR_Qsx = 0
    MAR_Qsx = 0;
else
    FDR_Qsx = sum(TP_Qsx) / (sum(TP_Qsx) + sum(FN_Qsx))
    MAR_Qsx = sum(FN_Qsx) / (sum(TP_Qsx) + sum(FN_Qsx));
end
    
if sum(FP_Qsx) == 0 && sum(TN_Qsx) == 0
    FAR_Qsx = 0
else
    FAR_Qsx = sum(FP_Qsx) / (sum(FP_Qsx) + sum(TN_Qsx))
end

% ———— phi_dx ————
TP_phi_dx = zeros(size(X1_test,1),1);  
TN_phi_dx = zeros(size(X1_test,1),1);
FP_phi_dx = zeros(size(X1_test,1),1);
FN_phi_dx = zeros(size(X1_test,1),1);

for count = 1:size(X1_test,1)    
    if phi_dx_index_test(count) > phi_dx_lim && Qx_index_pca_test(count) > Qx_lim_pca
        TP_phi_dx(count) = 1;
    elseif phi_dx_index_test(count) < phi_dx_lim && Qx_index_pca_test(count) < Qx_lim_pca
        TN_phi_dx(count) = 1;
    elseif phi_dx_index_test(count) > phi_dx_lim && Qx_index_pca_test(count) < Qx_lim_pca
        FP_phi_dx(count) = 1;
    elseif phi_dx_index_test(count) < phi_dx_lim && Qx_index_pca_test(count) > Qx_lim_pca
        FN_phi_dx(count) = 1;
    end
end
if sum(TP_phi_dx) == 0 && sum(FN_phi_dx) == 0
    FDR_phi_dx = 0
    MAR_phi_dx = 0;
else
    FDR_phi_dx = sum(TP_phi_dx) / (sum(TP_phi_dx) + sum(FN_phi_dx))
    MAR_phi_dx = sum(FN_phi_dx) / (sum(TP_phi_dx) + sum(FN_phi_dx));
end
    
if sum(FP_phi_dx) == 0 && sum(TN_phi_dx) == 0
    FAR_phi_dx = 0
else
    FAR_phi_dx = sum(FP_phi_dx) / (sum(FP_phi_dx) + sum(TN_phi_dx))
end