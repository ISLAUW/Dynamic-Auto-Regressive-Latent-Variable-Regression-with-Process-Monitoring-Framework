function [P_vd, lamda_vd, T2_lim_vd, Q_lim_vd] = PCA(Vd, a_vd)

n = size(Vd,1);
alpha = 0.01;
level = 1-alpha;

[U2,D2,V2] = svd(Vd,'econ');

P_vd = V2(:,1:a_vd);
Tx = Vd * P_vd; % input-principal scores

if size(D2,2) == 1
    Sx = D2(1);
else
    Sx = diag(D2);
end
mm = length(Sx);
lamda_vd = 1/(n-1) * diag(Sx(1:a_vd).^2);

gx = 1/(n-1) * sum(Sx(a_vd+1:mm).^4) / sum(Sx(a_vd+1:mm).^2);
hx = (sum(Sx(a_vd+1:mm).^2))^2 / sum(Sx(a_vd+1:mm).^4);

T2_lim_vd = chi2inv(level, a_vd);   % output-irrelevant but input-relevant based on x
Q_lim_vd = gx * chi2inv(level, hx); % potentially output-relevant based on x