%% ———— DArLVR ————
function [P,Q,C,W,Alpha,Beta,Y1_debug] = drlvr_arx(X1,Y1,a,gamma_1,gamma_2,s1,s2)
% X1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% X1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s1 -- the lag parameter to denote the degree of dynamics corresponding to output (u)
% s2 -- the lag parameter to denote the degree of dynamics corresponding to input (t)
% gamma_1 -- the regularization term

[n,m] = size(X1); np = size(Y1,2); 
s = max(s1,s2); N = n-s;
Y1_debug = zeros(n,np); 

% ———— Initialize ————
% Initialize w and q
w = ones(m,1);
q = ones(np,1); 
l = 0;
W = zeros(0,0); P = zeros(0,0); Q = zeros(0,0); C = zeros(0,0);
Alpha = zeros(0,0); Beta = zeros(0,0); Theta = zeros(0,0);

for l = 1:a
    % Dynamic outer modeling
    iter = 0;
    t = X1*w;
    while true
        temp_t = t;
        Ys = Y1(s+1:N+s,:);
        
        % Form Ts and Us
        Ts = zeros(N,s2+1);
        for i = 0:s2
            Ts(:,i+1) = t(s2-i+1:s2-i+N,:);
        end
        
        u = Y1*q;
        us = Ys*q;
        Us = zeros(N,s1);
        for i = 1:s1
            Us(:,i) = u(s-i+1:s-i+N,:);
        end
        
        Hs = [Us Ts];      
        theta = inv(Hs'*Hs + gamma_2*eye(size(Hs'*Hs)))*Hs'*us;
        alpha = theta(1:s1);
        beta = theta(s1+1:end);
        
        Xh_beta = zeros(N,m);
        for j = 0:s2
            Xh_beta = Xh_beta + beta(j+1) * X1(s-j+1:s-j+N,:);
        end
        Yh_alpha = zeros(N,np);
        for j = 1:s1
            Yh_alpha = Yh_alpha + alpha(j) * Y1(s-j+1:s-j+N, :);
        end
        
        G = inv(Xh_beta'*Xh_beta + gamma_1*eye(size(Xh_beta'*Xh_beta)))*Xh_beta'*(Ys - Yh_alpha);
        w = G*q;
        t = X1*w;
        
        q = (Ys - Yh_alpha)'*(Yh_alpha*q + Xh_beta*w) + Yh_alpha'*Ys*q;
        q = q/norm(q);
        
        if norm(temp_t - t) < 1e-4 || norm(temp_t + t) < 1e-4
            break;
        end

        iter = iter + 1
        if iter > 1000
            fprintf('---- 500 Iterations ---a: %d, s1: %d, s2, %d\n', a, s1, s2);
            break;
        end
    end
    
    %% ———— Dynamic inner modeling ————
    us_hat = Us*alpha + Ts*beta;
        
   %% ———— Deflation ———— 
    p = X1'*t/(t'*t);
    c = Ys'*us_hat/(us_hat'*us_hat);
    
    X1 = X1 - t*p';
    Y1(1:s,:) = Y1(1:s,:) - t(1:s)*c';
    Y1(s+1:n,:) = Y1(s+1:n,:) - us_hat * c';
    
    Y1_debug(s+1:n,:) = Y1_debug(s+1:n,:) + us_hat * c';

    l = l + 1;
    
    P = [P p]; Q = [Q q]; C = [C c]; W = [W w];
    Alpha = [Alpha alpha]; Beta = [Beta beta]; 
end