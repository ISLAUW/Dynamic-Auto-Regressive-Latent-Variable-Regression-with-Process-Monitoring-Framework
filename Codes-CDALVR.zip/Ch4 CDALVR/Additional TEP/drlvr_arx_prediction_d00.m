clear all
clc
close all
format short;
tic

%% ———— Data ————
% ———— Training Data: Normal Data ————
filename_1 = 'E:\Research\DALVR & DrLVR_ARX\TEP_FaultFree_Training.csv';
d00 = csvread(filename_1,1,4);

T = 5; n = size(d00,1)/T;

% ———— Data Sampling ————
X0 = zeros(n,33); Y0 = zeros(n,1); 
for i = 1:n
     X0(i,:) = [d00((T*i-1),1:22),d00((T*i-1),42:52)]; 
     Y0(i,:) = d00((T*i-1),38);
end

% ———— Testing Data ————
filename_2 =  'E:\Research\DALVR & DrLVR_ARX\TEP_FaultFree_Testing.csv';
d00_te = csvread(filename_2,1,4);

X0_te = d00_te;
n_te = size(X0_te,1)/T;
% ———— Data Sampling ————
X0_test = zeros(n_te,33); Y0_test = zeros(n_te,1); 
for j = 1:n_te
     X0_test(j,:) = [X0_te((T*j-1),1:22),X0_te((T*j-1),42:52)]; 
     Y0_test(j,:) = X0_te((T*j-1),38);
end

% ———— Autoscale the training data and testing data ————
[X1,mx_train,vx_train] = autos(X0);
[Y1,my_train,vy_train] = autos(Y0);

X1_test = autos_test(X0_test,mx_train,vx_train);
Y1_test = autos_test(Y0_test,my_train,vy_train);

%% ———— Parameter Determination————
load drlvr_arx_factor_data.mat
%a=1;s1=1;s2=1;


s = max(s1,s2);

%% ———— MSE ————
%[P,Q,C,W,Alpha,Beta,Y1_debug] = drlvr_arx(X1,Y1,a,gamma_1,gamma_2,s1,s2);
%Y_error = Y1(s+1:end,:) - Y1_debug(s+1:end,:); 
%MSE_debug = sum(sum(Y_error.^2))/size(Y1_debug(s+1:end,:),1);

[Y1_predict,Y1xg_predict,Y1yg_predict] = drlvr_arx_predict(X1,Y1,X1,Y1,a,gamma_1,gamma_2,s1,s2);
[MSE_Y1,MSE_Y1xg,MSE_Y1yg] = drlvr_arx_mse(X1,Y1,X1,Y1,a,gamma_1,gamma_2,s1,s2);

% ———— Plotting ————
n = size(Y1,1);
figure
subplot(3, 1, 1)
plot(s+1:n, Y1_predict(s+1:n,1), 'r', s+1:n, Y1(s+1:n,1), 'b', 'LineWidth', 1.5);
title("Y_{pred}")

subplot(3, 1, 2)
plot(s+1:n, Y1xg_predict(s+1:n,1), 'r', s+1:n, Y1(s+1:n,1), 'b', 'LineWidth', 1.5);
title("Y_{xg}")

subplot(3, 1, 3)
plot(s+1:n, Y1yg_predict(s+1:n,1), 'r', s+1:n, Y1(s+1:n,1), 'b', 'LineWidth', 1.5);
title("Y_{yg}")
legend("Predicted values", "Actual values")

toc

[Y_predict,Yxg_predict,Yyg_predict] = drlvr_arx_predict(X1,Y1,X1_test,Y1_test,a,gamma_1,gamma_2,s1,s2);
[MSE_overall,MSE_Yxg,MSE_Yyg] = drlvr_arx_mse(X1,Y1,X1_test,Y1_test,a,gamma_1,gamma_2,s1,s2);

% ———— R2 ————
R2_Yh = corrcoef(Y1_test(s+1:end,:),Y_predict(s+1:end,:));
R2_Yhyg = corrcoef(Yyg_predict(s+1:end,:),Y1_test(s+1:end,:));
R2_Yhxg = corrcoef(Yxg_predict(s+1:end,:),Y1_test(s+1:end,:));

% ———— T ————
%R = W*pinv(P'*W); 
%T = X1*R;

% ———— Auto-correlation of T————
%auto_t1=autocorr(T(:,1));
%auto_t2=autocorr(T(:,2));

%figure;
%subplot(2,1,1);
%stem_t1=stem(auto_t1);
%subplot(2,1,2);
%stem_t2=stem(auto_t2);

% ———— Plotting ————
figure
subplot(3, 1, 1)
plot(s+1:n_te, Y_predict(s+1:n_te,1), 'r', s+1:n_te, Y1_test(s+1:n_te,1), 'b', 'LineWidth', 1.5);
title("Y_{pred}")

subplot(3, 1, 2)
plot(s+1:n_te, Yxg_predict(s+1:n_te,1), 'r', s+1:n_te, Y1_test(s+1:n_te,1), 'b', 'LineWidth', 1.5);
title("Y_{xg}")

subplot(3, 1, 3)
plot(s+1:n_te, Yyg_predict(s+1:n_te,1), 'r', s+1:n_te, Y1_test(s+1:n_te,1), 'b', 'LineWidth', 1.5);
title("Y_{yg}")
legend("Predicted values", "Actual values")

